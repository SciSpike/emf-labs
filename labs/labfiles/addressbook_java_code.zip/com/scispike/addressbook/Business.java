package com.scispike.addressbook;

import java.util.List;

/**
 * A business contact represents an organization.
 *
 * @model
 */
public interface Business extends Contact {
    /**
     * The name of the business
     * @model
     */
    public String getBusinessName();

    /**
     * The main phone number
     * @model 
     */
    public String getMainNumber();

    /**
     * A list of individuals in the business
     * @model type="Individual" oposite="workPlace"
     */
    public List getIndividualContacts();
}
