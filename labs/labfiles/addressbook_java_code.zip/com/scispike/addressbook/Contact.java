package com.scispike.addressbook;

import java.util.List;

/**
 * An contact represents an abstract entry in an address book.
 * The instances of contacts are either businesses or individuals
 *
 * @model abstract="true"
 */
public interface Contact  {
    /**
     * A set of  visiting or mailing addresses for a contact
     *
     * @model type="Address" containment="true"
     */
    public List getAddresses();	
}
