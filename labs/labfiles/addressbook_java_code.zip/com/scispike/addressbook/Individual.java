package com.scispike.addressbook;

/**
 * Represents the contact information for a person
 * @model
 */
public interface Individual extends Contact{
    /**
     * Optionally we may track the organization the
     * individual works for
     * @model opposite="individualContacts""
     */
    public Business getWorkPlace();

    /**
     * The family name of the individual
     * @model
     */
    public String getLastName();

    /**
     * The given name of the individual
     * @model
     */
    public String getFirstName();

    /**
     * The direct contact number for the work location
     * @model
     */
    public String getWorkNumber();

    /**
     * The mobile number for the individual
     * @model
     */
    public String getMobileNumber();

    /**
     * The email address of the individual
     * @model
     */
    public String getEmail();
}
