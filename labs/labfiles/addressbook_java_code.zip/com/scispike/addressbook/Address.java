package com.scispike.addressbook;

/**
 * The address holds a location used to visit or
 * for mailing.
 *
 * @model 
 */
public interface Address {

    /**
     * Retrieve the name used for this address
     * @model 
     */
    public String getAddressee();

    /**
     * Retrieve the street address
     * @model
     */
    public String getStreet();

    /**
     * Retrieve the zip code
     * @model 
     */
    public String getZipCode();
    
    /**
     * retrive the city
     * @model 
     */
    public String getCity();
}

