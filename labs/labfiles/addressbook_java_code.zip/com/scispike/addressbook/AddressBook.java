package com.scispike.addressbook;

import java.util.List;

/**
 * The address book is the root object for a set of contacts
 * @model
 */
public interface AddressBook {
    /**
     * Holds the name of the address book
     * @model
     */
    public String getName();
    
    /**
     * Holds the list of contact entries
     * @model type="Contact" containment="true"
     */
    public List getContacts();
}
